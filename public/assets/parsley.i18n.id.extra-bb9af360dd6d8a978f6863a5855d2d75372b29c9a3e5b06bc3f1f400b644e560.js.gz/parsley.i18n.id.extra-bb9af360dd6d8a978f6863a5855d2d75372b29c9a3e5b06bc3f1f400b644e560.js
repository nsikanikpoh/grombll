// Validation errors messages for Parsley
// Load this after Parsley

Parsley.addMessages('id', {
  dateiso: "Harus tanggal yang valid (YYYY-MM-DD)."
});
